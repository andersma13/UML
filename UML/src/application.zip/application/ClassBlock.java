package application;

import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;

public class ClassBlock extends GridPane
{
	
	private Text name = new Text();
	private HBox nameWrap = new HBox();
	private GridPane attr = new GridPane();
	private HBox attrWrap = new HBox();
	private GridPane oper = new GridPane();
	private HBox operWrap = new HBox();
	private GridPane desc = new GridPane();
	private HBox descWrap = new HBox();
	
	public ClassBlock(String nameIn)
	{
		
		this.getStyleClass().add("classBlock");
		
		name.setText(nameIn);
		nameWrap.getStyleClass().add("pad");
		attrWrap.getStyleClass().add("pad");
		operWrap.getStyleClass().add("pad");
		descWrap.getStyleClass().add("pad");
		
		nameWrap.getChildren().add(name);	
		attrWrap.getChildren().add(attr);
		operWrap.getChildren().add(oper);
		descWrap.getChildren().add(desc);
		
		this.add(nameWrap, 0, 0);
		this.add(attrWrap, 0, 1);
		this.add(operWrap, 0, 2);
		this.add(descWrap, 0, 3);
		
	}
	
	public ClassBlock(int[] intData, String[] stringData)
	{
		
		this.getStyleClass().add("classBlock");
		
		this.setWidth((double)intData[3]);
		this.setHeight((double)intData[4]);
		
		name.setText(stringData[0]);
		attr.addColumn(0, new Text(stringData[1]));
		oper.addColumn(0, new Text(stringData[2]));
		desc.addColumn(0, new Text(stringData[3]));
		
		nameWrap.getStyleClass().add("pad");
		attrWrap.getStyleClass().add("pad");
		operWrap.getStyleClass().add("pad");
		descWrap.getStyleClass().add("pad");
		
		nameWrap.getChildren().add(name);	
		attrWrap.getChildren().add(attr);
		operWrap.getChildren().add(oper);
		descWrap.getChildren().add(desc);
		
		this.add(nameWrap, 0, 0);
		this.add(attrWrap, 0, 1);
		this.add(operWrap, 0, 2);
		this.add(descWrap, 0, 3);
		
	}
	
	public void addAttr(String attrIn) 
	{
		
		attr.getStyleClass().add("pad");
		attr.addColumn(0, new Text(attrIn));
		
	}
	
	public void addOper(String operIn)
	{
		
		oper.getStyleClass().add("pad");
		oper.addColumn(0, new Text(operIn));
		
	}
	
	public void addDesc(String descIn)
	{
		
		desc.getStyleClass().add("pad");
		desc.addColumn(0,  new Text(descIn));
		
	}
}
