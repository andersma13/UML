package application;
	
import java.util.function.UnaryOperator;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.TextFormatter.Change;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

/*
 * TODO:
 * - Drag and drop elements
 * - Select specific elements (perhaps this.getIndex() on click?)
 * - Draw connections
 * - Save and load Model data
 * - Make ClassBlock size dynamic (ie. removing unused cells)
 */

public class Main extends Application 
{
	@Override
	public void start(Stage primaryStage) 
	{
		
		try 
		{
			
			// Set up the stage
			primaryStage.setMinHeight(600);
			primaryStage.setMinWidth(660);
			BorderPane root = new BorderPane();
			root.getStyleClass().add("root");
			GridPane tools = new GridPane();
			Pane center = new Pane();
			center.getStyleClass().add("center");
			Model data = new Model();
			
			// Define toolbar
			Button newClass = new Button("New class...");
			Button removeClass = new Button("Delete...");
			newClass.getStyleClass().add("toolbarButtons");
			removeClass.getStyleClass().add("toolbarButtons");
			tools.add(newClass,    0, 0);
			tools.add(removeClass, 0, 1);
			
			// Define New Class behavior
			newClass.setOnAction(new EventHandler<ActionEvent> ()
			{
				
				@Override
				public void handle(ActionEvent e)
				{
					
					// Define dialog stage
          final Stage newClassDialog = new Stage();
          newClassDialog.initModality(Modality.APPLICATION_MODAL);
          newClassDialog.initOwner(primaryStage);

          // Define interface
          GridPane newClassInterface = new GridPane();
          Text newClassTitle = new Text("New class...");
          TextField newClassName = new TextField();
          TextArea newClassAttr = new TextArea();
          TextArea newClassOper = new TextArea();
          TextArea newClassDesc = new TextArea();
          TextField newClassX = new TextField();
          TextField newClassY = new TextField();
          Button newClassSubmit = new Button("Submit");
          
          // Declare a TextFormatter filter to ensure integer values
    			UnaryOperator<Change> integers = change -> 
    			{

    				String text = change.getText();
    				return (text.matches("[0-9]*") ? change : null);

    			};
          
    			TextFormatter<String> forceIntX = new TextFormatter<>(integers);
    			TextFormatter<String> forceIntY = new TextFormatter<>(integers);
    			newClassX.setTextFormatter(forceIntX);
    			newClassY.setTextFormatter(forceIntY);
    			
    			// Define behavior on Submit
          newClassSubmit.setOnAction(new EventHandler<ActionEvent> ()
          {
          	
          	@Override
          	public void handle(ActionEvent e)
          	{
          		
          		// Create a new ClassModel object out of the given values
          		int i = data.addBlock(
          				new int[] { data.getTail(),
          						Integer.parseInt(newClassX.getText()),
          						Integer.parseInt(newClassY.getText()),
          						100, 100 },
          				new String[] { newClassName.getText(),
          					newClassAttr.getText(),
          					newClassOper.getText(),
          					newClassDesc.getText()} );
          		
          		// Generate ClassBlock object
          		ClassBlock newClass = data.generateClassBlock(i);
          		newClass.getStyleClass().add("classBlock");

          		// Place in the main window and close dialog
          		newClass.setLayoutX((double)data.getXPos(i));
          		newClass.setLayoutY((double)data.getYPos(i));
          		center.getChildren().add(newClass);
          		
          		newClassDialog.close();
          		
          	}
          });
          
          // Place elements on Dialog
          newClassName.setPromptText("Class name...");
          newClassAttr.setPromptText("Class Attributes...");
          newClassOper.setPromptText("Class Operations...");
          newClassDesc.setPromptText("Class Description...");
          newClassX.setPromptText("Class X");
          newClassY.setPromptText("Class Y");
          
          newClassInterface.add(newClassTitle,  0, 0, 2, 1);
          newClassInterface.add(newClassName,   0, 1, 2, 1);
          newClassInterface.add(newClassAttr,   0, 2, 2, 1);
          newClassInterface.add(newClassOper,   0, 3, 2, 1);
          newClassInterface.add(newClassDesc,   0, 4, 2, 1);
          newClassInterface.add(newClassX,      0, 5);
          newClassInterface.add(newClassY,      1, 5);
          newClassInterface.add(newClassSubmit, 1, 6);
          
          // Show Dialog
          Scene dialogScene = new Scene(newClassInterface, 300, 230);
          newClassDialog.setScene(dialogScene);
          newClassDialog.show();
          
				}
			});
			
			removeClass.setOnAction(new EventHandler<ActionEvent> () 
			{
				@Override
				public void handle(ActionEvent e)
				{
					  
				}
			});
			
			// Place elements on stage
			root.setLeft(tools);
			root.setCenter(center);
			Scene scene = new Scene(root, 660, 600);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
			
		} 
		catch(Exception e) 
		{
			
			e.printStackTrace();
			
		}
	}
	
	public static void main(String[] args) 
	{
		
		launch(args);
		
	}
}
